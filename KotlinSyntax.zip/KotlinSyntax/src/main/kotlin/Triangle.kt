import java.util.DoubleSummaryStatistics
import kotlin.math.sqrt

class Triangle(var _a: Point, var _b: Point, var _c: Point){
    var a = _a
        set(value) {
            checkCollinearity(value, _b, _c);
            _a = value
        }
    var b = _b
        set(value) {
            checkCollinearity(_a, value, _c);
            _b = value
        }
    var c = _c
        set(value) {
            checkCollinearity(_a, _b, value);
            _c = value
        }
    val A: Double = sqrt((_b.x-_a.x).toDouble() * (_b.x-_a.x) + (_b.y-_a.y) * (_b.y-_a.y));
    val B: Double = sqrt((_b.x-_c.x).toDouble() * (_b.x-_c.x) + (_b.y-_c.y) * (_b.y-_c.y));
    val C: Double = sqrt((_a.x-_c.x).toDouble() * (_a.x-_c.x) + (_a.y-_c.y) * (_a.y-_c.y));
    init {
        checkCollinearity(_a,_b,_c)
    }
    fun print() {
        println("This triangle has points: A=$_a, B=$_b, C=$_c");
    }
    fun getPerimeter(): Double {
        return A+B+C;
    }
    fun getArea(): Double{
        val s: Double = (A+B+C)/2;
        return sqrt(s*(s-A)*(s-B)*(s-C));
    }
    fun checkCollinearity(a: Point, b: Point, c: Point) {
        if ((b.y-a.y)*(c.x-b.x)==(c.y-b.y)*(b.x-a.x)){
            throw Exception("ERROR, Collinear points");
        }
    }
}

class Point(var x: Int = 0, var y: Int = 0)