fun main(args: Array<String>) {
    var a = Point(); var b = Point(); val c = Point();
    a.x = 0; a.y = 0;
    b.x = 0; b.y = 10;
    c.x = 4; c.y = 0;
    val triangle = Triangle(a, b, c);
    triangle.print();
    println("triangle.getPerimeter() = ${triangle.getPerimeter()}")
    println("triangle.getArea() = ${triangle.getArea()}")
    triangle.a = Point(2,5); //Throws error because of collinearity
}